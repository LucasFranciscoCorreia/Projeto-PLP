package li2.plp.expressions2.expression;

import li2.plp.expressions1.util.Tipo;
import li2.plp.expressions2.memory.AmbienteCompilacao;
import li2.plp.expressions2.memory.AmbienteExecucao;
import li2.plp.expressions2.memory.VariavelJaDeclaradaException;
import li2.plp.expressions2.memory.VariavelNaoDeclaradaException;

public class ExpProb<T extends ValorConcreto> extends ExpBinaria{

    private Expressao prob;
    /**
     * Construtor da classe.
     *
     * @param esq      a expressao da esquerda.
     * @param dir
     * @param p
     */
    public ExpProb(Expressao esq, Expressao dir, Expressao p) {
        super(esq, dir, "::");
        prob = p;
    }

    @Override
    protected boolean checaTipoElementoTerminal(AmbienteCompilacao amb) throws VariavelNaoDeclaradaException, VariavelJaDeclaradaException {
        return ((getEsq().getTipo(amb).eInteiro() || getEsq().getTipo(amb).eDecimal()) && (getDir().getTipo(amb).eInteiro() || getDir().getTipo(amb).eDecimal()));
    }

    @Override
    public Valor avaliar(AmbienteExecucao amb) throws VariavelNaoDeclaradaException, VariavelJaDeclaradaException {
        if (prob.avaliar(amb) instanceof ValorInteiro) {
            return Math.random() * 100 < ((ValorInteiro) this.prob.avaliar(amb)).valor() ? getEsq().avaliar(amb) : getDir().avaliar(amb);
        } else {
            return Math.random() * 100 < ((ValorDecimal) this.prob.avaliar(amb)).valor() ? getEsq().avaliar(amb) : getDir().avaliar(amb);
        }
    }

    @Override
    public Tipo getTipo(AmbienteCompilacao amb) throws VariavelNaoDeclaradaException, VariavelJaDeclaradaException {
        return getEsq().getTipo(amb);
    }

    @Override
    public ExpBinaria clone() {
        return new ExpProb<T>(esq.clone(), dir.clone(), prob);
    }
}

package li2.plp.expressions2.expression;

import li2.plp.expressions1.util.Tipo;
import li2.plp.expressions1.util.TipoPrimitivo;
import li2.plp.expressions2.memory.AmbienteCompilacao;
import li2.plp.expressions2.memory.VariavelJaDeclaradaException;
import li2.plp.expressions2.memory.VariavelNaoDeclaradaException;

public class ValorDecimal extends ValorConcreto<Double>{
    /**
     * cria um objeto encapsulando o String fornecido
     *
     * @param valor
     */
    public ValorDecimal(Double valor) {
        super(valor);
    }

    @Override
    public Tipo getTipo(AmbienteCompilacao amb) throws VariavelNaoDeclaradaException, VariavelJaDeclaradaException {
        return TipoPrimitivo.DECIMAL;
    }

    @Override
    public ValorConcreto<Double> clone() {
        return new ValorDecimal(this.valor());
    }
}
